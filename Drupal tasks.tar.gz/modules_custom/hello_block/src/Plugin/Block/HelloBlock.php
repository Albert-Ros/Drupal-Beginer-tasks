<?php

namespace Drupal\hello_block\Plugin\Block;

use Drupal\Core\Block\BlockBase;
/**
 * Class HelloBlock
 * @package Drupal\hello_block\Plugin\Block
 * @Block (
 * id = "hello_block_hello",
 * admin_label = @Translation("Hello Block"),
 * category = @Translation("Coll Block"),
 * )
 */

service: class HelloBlock extends BlockBase {

  public function build() {

    return [
      '#markup' => $this->t('Hello, World!'),
    ];
    $user = \Drupal\user\Entity\User::load(\Drupal::currentUser()
      ->id());
    \Drupal::cache()->set('my_cache_item', $school_list, \Drupal::time()->getRequestTime() + (86400));
    }






}

