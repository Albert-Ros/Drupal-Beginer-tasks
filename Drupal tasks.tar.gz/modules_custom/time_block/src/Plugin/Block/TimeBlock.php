<?php
namespace Drupal\time_block\Plugin\Block;
use Drupal\Core\Block\BlockBase;
use Drupal\views\Plugin\views\argument\NullArgument;

/**
 * Class TimeBlock
 * @package Drupal\hello_block\Plugin\Block
 * @Block (
 * id = "time_block_timeBlock",
 * admin_label = @Translation("time Block"),
 * category = @Translation("good Block"),
 * )
 */

class TimeBlock extends BlockBase {

  public function build() {
    function format_date($timestamp, $type = 'medium', $format = '', $timezone = NULL, $langcode = NULL) {
      return  \Drupal::service('date.formatter')
        ->format($timestamp, $type, $format, $timezone, $langcode);

    }


echo format_date(time(),'custom','d/m/Y/H:i:c');
    echo " ";
    setlocale(LC_ALL, 'ru_RU');
     echo date("l, j F Y, H:i");


  }

}
