<?php

namespace Drupal\write_log\Form;

use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Form\FormBase;                   // Базовый класс Form API
use Drupal\Core\Form\FormStateInterface;              // Класс отвечает за обработку данных

/**
 * Наследуемся от базового класса Form API
 * @see \Drupal\Core\Form\FormBase
 */
class ExForm extends FormBase {

  // метод, который отвечает за саму форму - кнопки, поля
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Ваше имя'),
      '#description' => $this->t('Имя не должно содержать цифр'),
      '#required' => TRUE,
    ];
    $form['email']=array(
      '#type'=>'textfield',
      '#title'=>t('Введите ваш e-mail'),
      '#description'=>t('Ваш e-mail идет сюда')
    );
    $form['year']=array(
      '#type'=>'select',
      '#title'=>t('Выберете ваш год рождения'),
      '#options'=>array('1999','2000','2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2020')
    );
    $form['gender'] =array(
      '#type'=>'radios',
      '#title'=>t('Пол'),
      '#options'=>array(t('M'),t('Ж'))
    );
    $form['body'] =array(
      '#type'=>'radios',
      '#title'=>t('Кол-во конечностей'),
      '#options'=>array(t('4'))
    );
    $form['super']=array(
      '#type'=>'select',
      '#multiple' => TRUE,
      '#title'=>t('Выберете ваш супер способность'),
      '#options'=>array('бессмертие','прохождение сквозь стены','левитация')
    );

    $form['biography'] = array(
      '#type' => 'textarea',
      '#title' => t(' Ваша Биография'),
      '#description' => t('Вы можите писать ЗДЕСЬ!!!'),
    );

    $form['contract'] =  array(
      '#type' => 'checkbox',
      '#title' => t('с контрактом ознакомлен'),
    );
    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Отправить форму'),
      '#ajax' => [
        'callback' => '::setMessage',
      ]
    ];
    $form['Message']=[
      '#markup' => '<div class="result_message">'
    ];

    return $form;
  }


  public function setMessage(array &$form, FormStateInterface $form_state) {
    $response = new AjaxResponse();
    $response->addCommand(
      new HtmlCommand(
        '.result_message',
         $this->t('Thank You Form is completed' )
      )
    );
    return $response;
  }

  // метод, который будет возвращать название формы
  public function getFormId() {
    return 'ex_form_exform_form';
  }

  // ф-я валидации
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $name = $form_state->getValue('name');
    $is_number = preg_match("/[\d]+/", $name, $match);
    $email = $form_state->getValue('email');
    $is_email = preg_match("/[0-9a-z]+@[a-z]/",$email , $match);
    if ($is_number > 0) {
      $form_state->setErrorByName('title', $this->t('Строка содержит цифру.'));
    }
    if (!$is_email) {
      $form_state->setErrorByName('email', $this->t('Формат ввода email не верен!'));
    }
  }



  // действия по сабмиту

  public function submitForm(array &$form, FormStateInterface $form_state) {


  }


}
