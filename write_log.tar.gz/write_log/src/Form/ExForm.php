<?php

namespace Drupal\write_log\Form;

use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Form\FormBase;

// Базовый класс Form API
use Drupal\Core\Form\FormStateInterface;

// Класс отвечает за обработку данных

/**
 * Наследуемся от базового класса Form API
 *
 * @see \Drupal\Core\Form\FormBase
 */
class ExForm extends FormBase {

  // метод, который отвечает за саму форму - кнопки, поля
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Ваше имя'),
      '#description' => $this->t('Имя не должно содержать цифр'),
      '#required' => TRUE,
    ];
    $form['email'] = [
      '#type' => 'textfield',
      '#title' => t('Введите ваш e-mail'),
      '#description' => t('Ваш e-mail идет сюда'),
    ];
    $form['year'] = [
      '#type' => 'select',
      '#title' => t('Выберете ваш год рождения'),
      '#options' => [
        '1999',
        '2000',
        '2001',
        '2002',
        '2003',
        '2004',
        '2005',
        '2006',
        '2007',
        '2008',
        '2009',
        '2010',
        '2020',
      ],
    ];
    $form['gender'] = [
      '#type' => 'radios',
      '#title' => t('Пол'),
      '#options' => [t('M'), t('Ж')],
    ];
    $form['body'] = [
      '#type' => 'radios',
      '#title' => t('Кол-во конечностей'),
      '#options' => [t('4')],
    ];
    $form['super'] = [
      '#type' => 'select',
      '#multiple' => TRUE,
      '#title' => t('Выберете ваш супер способность'),
      '#options' => ['бессмертие', 'прохождение сквозь стены', 'левитация'],
    ];

    $form['biography'] = [
      '#type' => 'textarea',
      '#title' => t(' Ваша Биография'),
      '#description' => t('Вы можите писать ЗДЕСЬ!!!'),
    ];

    $form['contract'] = [
      '#type' => 'checkbox',
      '#title' => t('с контрактом ознакомлен'),
    ];
    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Отправить форму'),
      '#ajax' => [
        'callback' => '::setMessage',
      ],
    ];
    $form['Message'] = [
      '#markup' => '<div class="result_message">',
    ];

    return $form;
  }

  function admin_callback() {
    $params = [
      'to' => 'albrol@mail.ru',
      'from' => 'albrol@mail.ru',

      'subject' => t('Admin mail'),
      'body' => t('this is simple mail'),
      'headers' => "from: 'albrol@mail.ru' \r\nReply-to: 'albrol@mail.ru'\r\nContent-type: text/plain; charset=UTF-8; format=flowed\r\n",
    ];


    //    $from = 'albrol@mail.ru';
    //    $to = 'albrol@mail.ru';
    $key = 'admin_email';
    //$headers = "from: {$from}\r\nReply-to: {$from}\r\nContent-type: text/plain; charset=UTF-8; format=flowed\r\n";
    \Drupal::service('plugin.manager.mail')->mail($key, $params);
  }

  /**
   * Implements hook_mail().
   */
  function exForm_mail($key, &$message, $params) {
    switch ($key) {
      // Ключ, добавленный при использовании функции drupal_mail()
      case 'admin_email':
        $message['to'] = $params['to'];
        $message['subject'] = $params['subject'];
        $message['from'] = $params['from'];
        $message['headers'] = $params['headers'];
        $message['body'] = $params['body'];
        break;
    }
  }


  public function setMessage(array &$form, FormStateInterface $form_state) {
    $response = new AjaxResponse();
    $response->addCommand(
      new HtmlCommand(
        '.result_message',
        $this->admin_callback()


      )
    );
    return $response;
  }

  // метод, который будет возвращать название формы
  public function getFormId() {
    return 'ex_form_exform_form';
  }

  // ф-я валидации
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $name = $form_state->getValue('name');
    $is_number = preg_match("/[\d]+/", $name, $match);
    $email = $form_state->getValue('email');
    $is_email = preg_match("/[0-9a-z]+@[a-z]/", $email, $match);
    if ($is_number > 0) {
      $form_state->setErrorByName('title', $this->t('Строка содержит цифру.'));
    }
    if (!$is_email) {
      $form_state->setErrorByName('email', $this->t('Формат ввода email не верен!'));
    }
  }


  // действия по сабмиту

  public function submitForm(array &$form, FormStateInterface $form_state) {


  }


}
