(function ($, Drupal) {
  Drupal.behaviors.myBehaviour = {
    attach: function (context, settings) {
      var ar = {};
      var price;
      var type = 0;
      var dist = 0;
      console.log(settings.pizza.distPrice);
      $('#edit-quantity > div > div > select', context).change(function () {
        ar[$(this).attr('name').match(/\[(.*?)\]/)[1]] = $(this).children('option:selected').val();
        type = 0;
        console.log(ar);
        for (var key in ar) {
          // console.log(key);
          type += ar[key] * settings.pizza.typePrice[key]['Price'];
        }
        $("#edit-price").val(Number(Number(type) + Number(dist)));
      })

      $('#edit-district > div > input', context).click(function () {
        // console.log($(this).children('option:selected').val());
        // settings.pizza.typePrice[$(this).attr('name')]['Price'] * $(this).children('option:selected').val()
        if ($(this).prop("checked")) {
          console.log(settings.pizza.distPrice);
          dist = settings.pizza.distPrice[Number($(this).attr('value'))]['Price'];
          $("#edit-price").val(Number(Number(type) + Number(dist)));
        }
      })

    }
  }
})(jQuery, Drupal);
