<?php
namespace Drupal\custom_entity\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Url;

class Custom_entity extends ContentEntityBase implements ContentEntityInterface {

  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {

    $fields['id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('ID'))
      ->setDescription(t('The ID of the  entity.'))
      ->setReadOnly(TRUE)
      ->setSettings(array(
        'max_length'=>12
      ));


    $fields['uuid'] = BaseFieldDefinition::create('uuid')
      ->setLabel(t('UUID'))
      ->setDescription(t('The UUID of the  entity.'))
      ->setReadOnly(TRUE);


    $fields['ticket_id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('ticket_id'))
      ->setDescription(t('field ticket_id'))
      ->setSettings(array(
      'max_length'=>12,
      'default_value' => 0,
    ));

    $fields['user_id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('user_id'))
      ->setDescription(t(' field user_id'))
      ->setSettings(array(
        'max_length'=>12,
        'default_value' => 0,
      ));

    // String field.
    $fields['bin_id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('bin_id'))
      ->setDescription(t('field bin_id'))
      ->setSettings(array(
        'max_length'=>12,
        'default_value' => 0,
      ));

    $fields['created'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('created'))
      ->setDescription(t('field created'))
      ->setSettings(array(
        'max_length'=>12,
        'default_value' =>'',
      ));
    $fields['action'] = BaseFieldDefinition::create('varchar')
      ->setLabel(t('action'))
      ->setDescription(t('field action'))
      ->setSettings(array(
        'max_length'=>25,
        'collate'=>'utf8_unicode_ci',
        'default_value' =>''
      ));

    $fields['hours'] = BaseFieldDefinition::create('decimal')
      ->setLabel(t('hours'))
      ->setDescription(t('field hours'))
      ->setSettings(array(
        'precision' => 10,
        'scale' => 2,
        'default_value' =>''
      ));
    $fields['entry'] = BaseFieldDefinition::create('string')
      ->setLabel(t('entry'))
      ->setDescription(t('field entry'))
      ->setSettings(array(
        'default_value' => '',
        'max_length' => 250,
        'text_processing' => 0,
      ));

    return $fields;
  }

  public function toUrl($rel = 'canonical', array $options = []) {
    // Return default URI as a base scheme as we do not have routes yet.
    return Url::fromUri('base:entity/example/' . $this->id(), $options);
  }
}
